<?php

 define('EMAIL', 'yourEmailAddress@gmail.com');
 define('PASS', 'YourPassword');
 define('DB_HOST','127.0.0.1');
 define('DB_USER','root');
 define('DB_PASS','');
 define('DB_NAME','YourDatabaseName');
 define('root_directory','C:/xampp/htdocs/zyro/my_shop/my_shop/local_system/');
?>